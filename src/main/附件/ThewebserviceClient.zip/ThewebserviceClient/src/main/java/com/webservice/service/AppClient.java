package com.webservice.service;
/***
 * 
 * @author Eternity
 *	除了此运行类是手动增加的，该包下的其他文件均为自动生成的。自动生成的执行代码为：
 *	在cmd命令下，进入客户端程序的绝对路径src/main/java下，
 *	使用：
 *		wsimport -keep http://localhost:8099/getwebservice?wsdl
 *	其中：
 *		WebServiceImpl类为最重要的类，其他的类除了package-info类，都可以删除
 *	注意：
 *		服务类必须启动：访问http://localhost:8099/getwebservice?wsdl能够访问到文件
 */
public class AppClient {
	public static void main(String[] args) {
		WebServiceImplService factory = new WebServiceImplService();
		WebServiceImpl wsImpl = factory.getWebServiceImplPort();
		System.out.println(wsImpl.sayHello("你好，世界！"));
	}
}
