@javax.xml.bind.annotation.XmlSchema(namespace = "http://service.webservice.com/")
package com.webservice.service;
