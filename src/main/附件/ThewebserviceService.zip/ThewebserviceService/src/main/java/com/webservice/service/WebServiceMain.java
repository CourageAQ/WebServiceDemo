package com.webservice.service;

import javax.xml.ws.Endpoint;

public class WebServiceMain {
	public static void main(String[] args) {
		String address = "http://localhost:8099/getwebservice";
		Endpoint.publish(address, new WebServiceImpl());
		System.out.println("发布成功！");
	}
}
